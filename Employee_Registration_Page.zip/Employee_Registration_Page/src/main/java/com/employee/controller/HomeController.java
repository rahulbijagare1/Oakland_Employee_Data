package com.employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.employee.entities.Employee;
import com.employee.service.EmployeeService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class HomeController {
	
	@Autowired
	EmployeeService employeeService;

	  @RequestMapping("/welcome") 
	  public String Welcome(HttpServletRequest request) { 
		  request.setAttribute("mode", "MODE_HOME");
		  return ("welcome");
	  }
	  @RequestMapping("/registration")
		public String registration(HttpServletRequest request) {
			request.setAttribute("mode", "MODE_REGISTER");
			return "welcome";
		}
	  
	  @PostMapping("/saveEmployee")
		public String registerUser(@ModelAttribute Employee employee, BindingResult bindingResult, HttpServletRequest request) {
			employeeService.saveMyEmployee(employee);
			request.setAttribute("mode", "MODE_HOME");
			return "welcome";
		}
	  @GetMapping("/showEmployee")
		public String showAllUsers(HttpServletRequest request) {
			request.setAttribute("users", employeeService.showAllEmployees());
			request.setAttribute("mode", "ALLEMPLOYEE");
			return "welcome";
		}

		@RequestMapping("/deleteemployee")
		public String deleteEmployee(@RequestParam int id, HttpServletRequest request) {
			employeeService.deleteMyEmployee(id);
			request.setAttribute("users", employeeService.showAllEmployees());
			request.setAttribute("mode", "ALLEMPLOYEE");
			return "welcome";
		}
		
		@RequestMapping("/editemployee")
		public String editEmployee(@RequestParam int id,HttpServletRequest request) {
			request.setAttribute("employee", employeeService.editEmployee(id));
			request.setAttribute("mode", "MODE_UPDATE");
			return "welcome";
		}
		
		@RequestMapping("/login")
		public String login(HttpServletRequest request) {
			request.setAttribute("mode", "MODE_LOGIN");
			return "welcome";
		}
		
		@RequestMapping ("/loginemployee")
		public String loginUser(@ModelAttribute Employee employee, HttpServletRequest request) {
			if(employeeService.findByloginIdAndPassword(employee.getEmployee(), employee.getPassword())!=null) {
				return "home";
			}
			else {
				request.setAttribute("error", "Invalid LoginId or Password");
				request.setAttribute("mode", "MODE_LOGIN");
				return "welcome";
				
			}
		}

	 
}
