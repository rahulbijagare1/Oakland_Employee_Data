package com.employee.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.employee.entities.Employee;
import com.employee.service.EmployeeService;

@Controller
public class RestController {
	
	@Autowired
	private EmployeeService employeeService; 
	@GetMapping("/")
public String home()
{
	return "Home Page";
	
}
	@GetMapping("/saveEmployee")
	public String saveEmployee(@RequestParam String name,@RequestParam Date dob,@RequestParam String gender,
			@RequestParam String address,@RequestParam String city,@RequestParam String state,@RequestParam String loginId,
			@RequestParam String password)
	
	{
		Employee employee= new Employee(0, name,dob,gender,address,city,state,loginId,password);
		employeeService.saveMyEmployee(employee);
		return "Employee is Succesfully saved...";
		
	}
}
