package com.employee.repository;

import org.springframework.data.repository.CrudRepository;

import com.employee.entities.Employee;

public interface EmployeeRepository extends CrudRepository<Employee, Integer> {
	public Employee findByLoginIdAndPassword(String loginId, String password);

	


}
