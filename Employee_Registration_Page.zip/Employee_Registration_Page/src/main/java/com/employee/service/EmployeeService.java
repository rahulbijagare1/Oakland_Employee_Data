package com.employee.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.employee.entities.Employee;
import com.employee.repository.EmployeeRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class EmployeeService {
	
	private final EmployeeRepository employeeRepository;
	
	public EmployeeService(EmployeeRepository employeeRepository) {
		this.employeeRepository=employeeRepository;
		
	}
	
public void saveMyEmployee(Employee employee)
{
	employeeRepository.save(employee);
}
public List<Employee> showAllEmployees(){
	List<Employee> employees = new ArrayList<Employee>();
	for(Employee employee : employeeRepository.findAll()) {
		employees.add(employee);
	}
	
	return employees;
}

public void deleteMyEmployee(int id) {
	employeeRepository.deleteById(id);
}

public Employee editEmployee(int id) {
	return employeeRepository.findOne(id);
}

public Employee findByloginIdAndPassword(String loginId, String password) {
	return employeeRepository.findByLoginIdAndPassword(loginId, password);
}

}
